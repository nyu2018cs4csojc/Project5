#define GL_SILENCE_DEPRECATION

#ifdef _WINDOWS
#include <GL/glew.h>
#endif

#define GL_GLEXT_PROTOTYPES 1
#include <SDL.h>
#include <SDL_opengl.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include <SDL_mixer.h>
#include <vector>
using namespace std;

SDL_Window* displayWindow;
bool gameIsRunning = true;

ShaderProgram program;
glm::mat4 viewMatrix, projectionMatrix;
#define FIXED_TIMESTEP 0.016f
float lastTicks = 0;
float accumulator = 0.0f;
float endtime = 0;
float messagetime = 0;
GLuint TextureIDFont;
GLuint TextureIDMap;
GLuint TextureIDPlayer1;
GLuint TextureIDPlayer2;
GLuint TextureIDHeart;
GLuint TextureIDEnemy1;
GLuint TextureIDEnemy2;
Mix_Music* music;
Mix_Chunk* sound;
int lives = 3;
bool levelcomplete = false;
bool jump = false;
int frames = 0;


class Entity
{
public:
    glm::mat4 modelMatrix;
    GLuint TextureID;
    float vertices[12];
    float texcoords[12];
    glm::vec3 position;
    glm::vec3 velocity;
    glm::vec3 acceleration;
    Entity()
    {
        modelMatrix = glm::mat4(1.0f);
        velocity = glm::vec3(0);
        acceleration = glm::vec3(0);
    }
    Entity(glm::vec3 p, float w, float h, GLuint t) : texcoords{ 0, h, w, h, w, 0, 0, h, w, 0, 0, 0 }, vertices{ -w / 2, -h / 2, w / 2, -h / 2, w / 2, h / 2, -w / 2, -h / 2, w / 2, h / 2, -w / 2, h / 2 }
    {
        modelMatrix = glm::mat4(1.0f);
        velocity = glm::vec3(0);
        acceleration = glm::vec3(0);
        position = p;
        TextureID = t;
        modelMatrix = glm::translate(modelMatrix, position);
    }
    Entity(float u, float v, glm::vec3 p) : texcoords{u, v + 0.0625f, u + 0.0625f, v + 0.0625f, u + 0.0625f, v, u, v + 0.0625f, u + 0.0625f, v, u, v}, vertices{-0.5, -0.5, 0.5, -0.5, 0.5, 0.5, -0.5, -0.5, 0.5, 0.5, -0.5, 0.5}
    {
        TextureID = TextureIDFont;
        modelMatrix = glm::mat4(1.0f);
        velocity = glm::vec3(0);
        acceleration = glm::vec3(0);
        position = p;
        modelMatrix = glm::translate(modelMatrix, position);
    }
    void Update(float deltaTime)
    {
        velocity += acceleration * deltaTime;
        position += velocity * deltaTime;
        modelMatrix = glm::mat4(1.0f);
        modelMatrix = glm::translate(modelMatrix, position);
    }
    void Render()
    {
        program.SetModelMatrix(modelMatrix);
        glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, vertices);
        glEnableVertexAttribArray(program.positionAttribute);
        glVertexAttribPointer(program.texCoordAttribute, 2, GL_FLOAT, false, 0, texcoords);
        glEnableVertexAttribArray(program.texCoordAttribute);
        glBindTexture(GL_TEXTURE_2D, TextureID);
        glDrawArrays(GL_TRIANGLES, 0, 6);
        glDisableVertexAttribArray(program.positionAttribute);
        glDisableVertexAttribArray(program.texCoordAttribute);
    }
};

class Map
{
public:
    const int width;
    const int height;
    vector<vector<int>> leveldata;
    GLuint TextureID;
    //int texturewidth;
    //int textureheight;
    Map(int width, int height, vector<vector<int>> texturedata) : width(width), height(height), TextureID(TextureIDMap) 
    {
        for (int i = 0; i < height; i++)
        {
            vector<int> temp;
            for (int j = 0; j < width; j++)
            {
                temp.push_back(texturedata[i][j]);
            }
            leveldata.push_back(temp);
        }
    }
    void Build()
    {
        float w = 1.0f / 6;
        float h = 1.0f / 2;
        for (float y = 0; y < height; y++)
        {
            for (float x = 0; x < width; x++)
            {
                int tex = leveldata[int(y)][int(x)];
                float u = float(tex % 6) / 6;
                float v = float(tex / 6) / 2;
                float vertices[12] = { x, y, x + 1, y, x + 1, y + 1, x, y, x + 1, y + 1, x, y + 1 };
                float texcoords[12] = { u, v + h, u + w, v + h, u + w, v, u, v + h, u + w, v, u, v };
                Render(vertices, texcoords);
            }
        }
    }
    void Render(float vertices[12], float texcoords[12])
    {
        program.SetModelMatrix(glm::mat4(1.0f));
        glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, vertices);
        glEnableVertexAttribArray(program.positionAttribute);
        glVertexAttribPointer(program.texCoordAttribute, 2, GL_FLOAT, false, 0, texcoords);
        glEnableVertexAttribArray(program.texCoordAttribute);
        glBindTexture(GL_TEXTURE_2D, TextureIDMap);
        glDrawArrays(GL_TRIANGLES, 0, 6);
        glDisableVertexAttribArray(program.positionAttribute);
        glDisableVertexAttribArray(program.texCoordAttribute);
    }
    bool isObstacle(float y, float x)
    {
        if (leveldata[int(y)][int(x)] != 2 && leveldata[int(y)][int(x)] != 0)
        {
            return true;
        }
        return false;
    }
};

class Scene
{
public:
    Entity* title[10];
    Entity* subtitle[17];
    Map* map;
    Entity* hearts[3];
    Entity* player;
    Entity* text[7];
    vector<Entity*> enemies;
    virtual void Update(float deltatime) = 0;
    virtual void Render() = 0;
};

class Main : public Scene
{
public:
    Main(string name, string instructions)
    {
        float x;
        float u;
        float v;
        for (int i = 0; i < 10; i++)
        {
            x = 0.5f + i;
            u = (float)(name[i] % 16) / 16;
            v = (float)(name[i] / 16) / 16;
            title[i] = new Entity(u, v, glm::vec3(x, 6.5, 0));
        }
        size_t i = 0;
        size_t j = 0;
        x = 0.5;
        while (i < instructions.length())
        {
            if (instructions[i] == ' ')
            {
                x++; i++;
                continue;
            }
            u = (float)(instructions[i] % 16) / 16;
            v = (float)(instructions[i] / 16) / 16;
            subtitle[j] = new Entity(u, v, glm::vec3(x/2, 3.5, 0));
            i++; j++; x++;
        }
    }
    ~Main()
    {
        delete[] title;
        delete[] subtitle;
    }
    void Render()
    {
        for (Entity* i : title)
        {
            i->Render();
        }
        for (Entity* i : subtitle)
        {
            i->Render();
        }
    }
    void Update(float deltatime)
    {
        return;
    }
};

class Level : public Scene
{
public:
    Level(int enemy, int live, Map* levelmap)
    {
        map = levelmap;
        player = new Entity(glm::vec3(5, 4.5, 0), 1, 1, TextureIDPlayer1);
        for (int i = 0; i < 3; i++)
        {
            if (i < live)
            {
                hearts[i] = new Entity(glm::vec3(4 + i, 9.5, 0), 1, 1, TextureIDHeart);
            }
            else
            {
                hearts[i] = nullptr;
            }
        }
        for (int i = 0; i < enemy; i++)
        {
            enemies.push_back(new Entity(glm::vec3(5, 7.5 + 4.0 * i, 0), 1, 1, TextureIDEnemy1));
            enemies[i]->velocity.x = 1;
        }
    }
    ~Level()
    {
        delete map;
        delete[] hearts;
        delete player;
        delete[] text;
        for (size_t i = 0; i < enemies.size(); i++)
        {
            delete enemies[i];
        }
    }
    void Update(float deltatime)
    {
        if (player->position.x >= 9.5)
        {
            player->velocity.x = -1;
            player->position.x = 9.4;
        }
        else if (player->position.x <= 0.5)
        {
            player->velocity.x = 1;
            player->position.x = 0.6;
        }
        if (player->position.y >= map->height - 0.5)
        {
            player->velocity.y = -1;
            player->position.y = map->height - 0.6;
        }
        player->acceleration.y = -0.981f; 
        int posx = int(player->position.x);
        int posz = int(player->position.y);
        if (map->leveldata[int(player->position.y)][int(player->position.x)] == 0) 
        { 
            levelcomplete = true; 
            messagetime = 1; 
            player->position.x = int(player->position.x) + 0.5;
            player->position.y = int(player->position.y) + 0.5;
        }
        if ((map->isObstacle(player->position.y - 0.5, player->position.x - 0.5) || map->isObstacle(player->position.y - 0.5, player->position.x + 0.5)))
        {
            player->acceleration.y = 0;
            player->velocity.y = 0;
        }
        else
        {
            player->acceleration.y = -0.981f;
        }
        if (map->isObstacle(player->position.y + 0.5, player->position.x - 0.5) || map->isObstacle(player->position.y + 0.5, player->position.x + 0.5))
        {
            player->velocity.y = -1;
        }
        if (map->isObstacle(player->position.y - 0.5, player->position.x - 0.5) && map->isObstacle(player->position.y - 0.4, player->position.x - 0.5) || 
            map->isObstacle(player->position.y + 0.5, player->position.x - 0.5) && map->isObstacle(player->position.y + 0.4, player->position.x - 0.5))
        {
            player->velocity.x = 1;
        }
        if (map->isObstacle(player->position.y - 0.5, player->position.x + 0.5) && map->isObstacle(player->position.y - 0.4, player->position.x + 0.5) || 
            map->isObstacle(player->position.y + 0.5, player->position.x + 0.5) && map->isObstacle(player->position.y + 0.4, player->position.x + 0.5))
        {
            player->velocity.x = -1;
        }
        if (player->velocity.y < 0 || frames > 0)
        {
            player->TextureID = TextureIDPlayer2;
            frames--;
        }
        else
        {
            player->TextureID = TextureIDPlayer1;
        }
        if (jump) { player->acceleration.y = 100; frames = 10; jump = false; }
        for (Entity* i : enemies)
        {
            if (i == nullptr) { continue; }
            if (i->position.x <= 1.5 || i->position.x >= 8.5)
            {
                i->velocity.x *= -1;
            }
            if (i->position.x - int(i->position.x) < 0.5)
            {
                i->TextureID = TextureIDEnemy1;
            }
            else
            {
                i->TextureID = TextureIDEnemy2;
            }
            if (abs(player->position.x - i->position.x) < 1 && abs(player->position.y - i->position.y) < 1)
            {
                delete hearts[lives - 1];
                hearts[lives - 1] = nullptr;
                lives--;
                Mix_PlayChannel(-1, sound, 0);
                messagetime = 1;
                if (lives != 0)
                {
                    player->position = glm::vec3(5, 4.5, 0);
                    player->velocity = glm::vec3(0);
                }
                return;
            }
            i->Update(FIXED_TIMESTEP);
        }
        player->Update(FIXED_TIMESTEP);
        viewMatrix = glm::mat4(1.0f);
        if (player->position.y < 5)
        {
            viewMatrix = glm::translate(viewMatrix, glm::vec3(0, 0, 0));
            for (int i = 0; i < lives; i++)
            {
                hearts[i]->modelMatrix = glm::translate(glm::mat4(1.0f), hearts[i]->position);
            }
        }
        else if (player->position.y > map->height - 5)
        {
            viewMatrix = glm::translate(viewMatrix, glm::vec3(0, 10 - map->height, 0));
            for (int i = 0; i < lives; i++)
            {
                hearts[i]->modelMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(hearts[i]->position.x, map->height - 0.5, 0));
            }
        }
        else
        {
            viewMatrix = glm::translate(viewMatrix, glm::vec3(0, 5 - player->position.y, 0));
            for (int i = 0; i < lives; i++)
            {
                hearts[i]->modelMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(hearts[i]->position.x, 4.5 + player->position.y, 0));
            }
        }
    }
    void Render()
    {
        program.SetViewMatrix(viewMatrix);
        map->Build();
        player->Render();
        for (int i = 0; i < lives; i++)
        {
            if (hearts[i] != nullptr)
            {
                hearts[i]->Render();
            }
        }
        for (Entity* i : enemies)
        {
            if (i != nullptr)
            {
                i->Render();
            }
        }
        for (int i = 0; i < 7; i++)
        {
            if (text[i] != nullptr)
            {
                text[i]->Render();
            }
        }
    }
};

GLuint LoadTexture(const char* filePath) {
    int w, h, n;
    unsigned char* image = stbi_load(filePath, &w, &h, &n, STBI_rgb_alpha);
    if (image == NULL) {
        std::cout << "Unable to load image. Make sure the path is correct\n";
        assert(false);
    }
    GLuint textureID;
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    stbi_image_free(image);
    return textureID;
}

Scene* game[4];
Scene* loading;

void Initialize() {
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);
    displayWindow = SDL_CreateWindow("Platformers!", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 480, SDL_WINDOW_OPENGL);
    SDL_GLContext context = SDL_GL_CreateContext(displayWindow);
    SDL_GL_MakeCurrent(displayWindow, context);
#ifdef _WINDOWS
    glewInit();
#endif
    glViewport(0, 0, 640, 480);
    program.Load("shaders/vertex_textured.glsl", "shaders/fragment_textured.glsl");
    viewMatrix = glm::mat4(1.0f);
    projectionMatrix = glm::ortho(0.0f, 10.0f, 0.0f, 10.0f, -1.0f, 1.0f);
    program.SetProjectionMatrix(projectionMatrix);
    program.SetViewMatrix(viewMatrix);
    glUseProgram(program.programID);
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 4096);
    TextureIDFont = LoadTexture("font1.png");
    TextureIDMap = LoadTexture("tilemap_packed.png");
    TextureIDPlayer1 = LoadTexture("character_0000.png");
    TextureIDHeart = LoadTexture("tile_0044.png");
    TextureIDEnemy1 = LoadTexture("character_0004.png");
    TextureIDPlayer2 = LoadTexture("character_0001.png");
    TextureIDEnemy2 = LoadTexture("character_0005.png");
    music = Mix_LoadMUS("music.mp3");
    sound = Mix_LoadWAV("sound.wav");
    game[0] = new Main("PLATFORMERS!", "Press Enter to Start");
    vector<vector<int>> background1 =
    { {9, 9, 11, 11, 11, 11, 11, 11, 9, 9},
    {2, 2, 9, 11, 11, 11, 11, 9, 2, 2},
    {2, 2, 2, 9, 11, 11, 9, 2, 2, 2},
    {2, 2, 2, 2, 9, 9, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {5, 5, 5, 2, 2, 2, 2, 5, 5, 5},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 5},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 5},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 5},
    {5, 5, 5, 5, 5, 5, 2, 2, 5, 5},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 5, 5, 2, 2, 2, 2, 2, 2}, 
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 5, 5, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 5, 5, 5, 2, 2, 2, 2, 2},
    {2, 2, 2, 0, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2}};
    Map* level1 = new Map(10, 20, background1);
    game[1] = new Level(1, lives, level1);
    vector<vector<int>> background2 =
    { {9, 9, 11, 11, 11, 11, 11, 11, 9, 9},
    {2, 2, 9, 11, 11, 11, 11, 9, 2, 2},
    {2, 2, 2, 9, 11, 11, 9, 2, 2, 2},
    {2, 2, 2, 2, 9, 9, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {5, 5, 5, 2, 2, 2, 2, 5, 5, 5},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 5},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 5},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 5},
    {5, 5, 2, 2, 5, 5, 5, 5, 5, 5},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 5},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 5},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 5},
    {5, 5, 5, 5, 5, 5, 2, 2, 5, 5},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 5, 5, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 5, 5, 5, 5, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 5, 5, 5, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 5, 5, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 5, 5, 5, 2, 2, 2, 2},
    {2, 2, 2, 2, 0, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2} };
    Map* level2 = new Map(10, 25, background2);
    game[2] = new Level(2, lives, level2);
    vector<vector<int>> background3 =
    { {9, 9, 11, 11, 11, 11, 11, 11, 9, 9},
    {2, 2, 9, 11, 11, 11, 11, 9, 2, 2},
    {2, 2, 2, 9, 11, 11, 9, 2, 2, 2},
    {2, 2, 2, 2, 9, 9, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {5, 5, 5, 2, 2, 2, 2, 5, 5, 5},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 5},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 5},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 5},
    {5, 2, 2, 5, 5, 5, 5, 2, 2, 5},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 5},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 5},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 5},
    {5, 5, 5, 5, 5, 2, 2, 5, 5, 5},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 5},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 5},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 5},
    {5, 5, 2, 2, 5, 5, 5, 5, 5, 5},
    {5, 2, 2, 2, 5, 2, 2, 2, 2, 5},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 5},
    {5, 2, 2, 2, 2, 5, 2, 2, 2, 5},
    {5, 5, 5, 5, 5, 5, 2, 2, 5, 5},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {5, 5, 5, 5, 5, 2, 2, 2, 2, 2},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 5, 5, 5, 5},
    {5, 5, 5, 5, 2, 2, 2, 2, 2, 2},
    {5, 0, 2, 2, 2, 2, 2, 2, 2, 2},
    {5, 2, 2, 2, 2, 2, 2, 2, 2, 2}};
    Map* level3 = new Map(10, 30, background3);
    game[3] = new Level(3, lives, level3);
    loading = game[0];
    Mix_PlayMusic(music, -1);
}

void ProcessInput() {
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        switch (event.type)
        {
        case SDL_QUIT:
        case SDL_WINDOWEVENT_CLOSE:
            gameIsRunning = false;
            break;
        case SDL_KEYDOWN:
            if (event.key.keysym.sym == SDLK_RETURN && loading == game[0])
            {
                glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
                loading = game[1];
            }
            if (event.key.keysym.sym == SDLK_SPACE && loading != game[0])
            {
                jump = true;
            }
            break;
        }
    }
    const Uint8* keys = SDL_GetKeyboardState(NULL);
    if (keys[SDL_SCANCODE_LEFT] && loading != game[0])
    {
        loading->player->velocity.x += -0.001f;
    }
    if (keys[SDL_SCANCODE_RIGHT] && loading != game[0])
    {
        loading->player->velocity.x += 0.001f;
    }
}

void Update() 
{
    float ticks = (float)SDL_GetTicks() / 1000.0f;
    float deltaTime = ticks - lastTicks;
    lastTicks = ticks;
    deltaTime += accumulator;
    if (deltaTime < FIXED_TIMESTEP)
    {
        accumulator = deltaTime;
        return;
    }
    while (deltaTime >= FIXED_TIMESTEP)
    {
        if (lives != 0 && !levelcomplete)
        {
            loading->Update(FIXED_TIMESTEP);
        }
        else
        {
            if (messagetime == 1)
            {
                float y = loading->player->position.y;
                float x, u, v;
                string message;
                int space;
                if (levelcomplete && loading != game[3])
                {
                    message = "LEVELUP";
                    space = 5;
                }
                else if (levelcomplete)
                {
                    message = "YOUWIN!";
                    space = 3;
                }
                else
                {
                    message = "YOULOSE";
                    space = 3;
                }
                for (int i = 0; i < 7; i++)
                {
                    x = 1.5f + i;
                    if (i >= space) { x++; }
                    u = (float)(message[i] % 16) / 16;
                    v = (float)(message[i] / 16) / 16;
                    loading->text[i] = new Entity(u, v, glm::vec3(x, y, 0));
                }
            }
            messagetime -= FIXED_TIMESTEP;
            if (levelcomplete && messagetime < 0)
            {
                for (int i = 1; i < 3; i++)
                {
                    if (loading == game[i])
                    {
                        loading = game[i + 1];
                        levelcomplete = false;
                        break;
                    }
                }
            }
        }
        deltaTime -= FIXED_TIMESTEP;
    }
    accumulator = deltaTime;
}

void Render() {
    glClear(GL_COLOR_BUFFER_BIT);
    loading->Render();
    SDL_GL_SwapWindow(displayWindow);
}

void Shutdown() {
    SDL_Quit();
}

int main(int argc, char* argv[]) {
    Initialize();

    while (gameIsRunning) {
        ProcessInput();
        Update();
        Render();
    }

    Shutdown();
    return 0;
}